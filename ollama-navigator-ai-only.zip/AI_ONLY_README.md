# Ollama / Qwen3 4B — AI部分のみの配布

抽出元: feature/ollama-navigator / 7ae741701ec53636066bef887f5286e73b2e1fb6
接続パッチの対象main: 251470aacf91279a07241453daf543b7f704e118

## 入っているもの

- ollama_explainer.py：ローカルOllama通信、プロンプト、応答検証。
- ecosystem_ai_context.py：最新の個体・集団の値を読む処理。
- annual_report.py：年間スナップショット、増減、ルール総括、履歴とJSON保存。
- ai_navigator.py：年間/個体の単一通信枠、非同期生成、AI画面。
- verify_ollama.py：Windows実機での接続・保存済み年間データの確認。
- data/ollama_config.json：localhost:11434 / qwen3:4b 等の設定。
- patches/：最新mainの2ファイルへAIの接続だけを加える参考パッチ。
- SOURCE.json：元コミットと、AIソース6ファイルのSHA-256。

main.py、world.py、organism.py、config.py、pixel_art.py、season_effects.py、タイトル・設定・セーブのソースやモデル本体は含めていません。
このZIPだけでゲームを起動するものではなく、既存プロジェクトへ組み込む部品です。

## 既存mainへの配置

1. このZIPを別のフォルダーへ展開します。
2. 上記6ファイルをゲームのmain.pyと同じ階層へコピーします。ollama_config.jsonだけは既存のdataフォルダー内に配置します。
3. 既存mainのルール解説は再利用します。以下はmainに既にあるファイルを使い、古い版で上書きしないでください。
   - navigator_explainer.py / status_explainer.py / status_panel.py
   - data/navigator_text.json / data/status_explanations.json
   - config.py / world.py / organism.py / season_effects.py
4. 画面表示・年間生成にはmain.pyとnavigator_panel.pyへの接続も必要です。以下の参考パッチを確認して適用します。

## 接続用の参考パッチ

Gitが利用できる場合、対象mainのチェックアウトで次を実行します。パスは展開場所に合わせてください。

```powershell
git apply --check "C:\展開場所\patches\navigator_panel_ai.patch" "C:\展開場所\patches\main_ai_hooks.patch"
git apply "C:\展開場所\patches\navigator_panel_ai.patch" "C:\展開場所\patches\main_ai_hooks.patch"
```

git apply --checkが失敗した場合は、対象の版が違うか、AIの接続が既にある可能性があります。パッチを見て必要な箇所を手作業で接続してください。

- navigator_panel.py：AI画面への切替、AI状態の更新、終了通知を追加。
- main.py：イベントにWorldを渡し、通常進行と世代送りのステップをAINavigator.advance経由にする。年間総括を読み終えるまで終了画面を保持し、終了時にcloseを呼ぶ。
- ステップ関数そのもの、生態系の計算やマップ描画、設定画面、セーブ機能を置き換えるパッチではありません。

## 起動・操作

Python依存は既存mainのrequirements.txtを使用します。追加Pythonライブラリは不要です。
WindowsのOllamaを起動し、ollama listでqwen3:4bが存在することを確認してください。

```powershell
.\.venv\Scripts\python.exe main.py
```

観察モード→設定→開始→N/解説→AIで表示します。

- 年間総括：既存SEASON_CYCLE（現在12世代）ごとに1回。160〜190文字・5〜6文、think=false。
- 個体解説：個体を選んで「選択個体」→「AI解説を更新」。40〜80文字。
- 新しい年間総括の完成までは前回を表示し、過去の総括は前後ボタンで確認。
- Ollama不在時はルール解説を表示。年間データ・入力・回答はreports/annual_*.jsonへ保存。

保存済み入力を実モデルへ再送信する診断コマンド（元のJSONは変更しません）：

```powershell
.\.venv\Scripts\python.exe verify_ollama.py --annual-report .\reports\annual_実際のファイル名.json --year 1
```

## この配布で対応していないこと

このAIコードは上記コミットから抽出したものです。Windows実機のQwen生成品質・速度は未確認です。
新しいセーブデータへ年間履歴・年初スナップショットを含めて復元する対応は、この抽出ファイルには含まれていません。
ロードで年の途中から観察を始めた場合、取得できた範囲を「途中まで」として扱います。以前のreportsのJSONを画面へ自動復元する機能もありません。
接続パッチの適用・構文・モジュール読込・簡易画面表示はクラウドで確認済みですが、最新mainとの全操作を統合検証した完成版ではありません。
